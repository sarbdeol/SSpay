// ============================================
// Admin Routes - Full CRUD + Dashboard
// ============================================
const router = require('express').Router();
const bcrypt = require('bcryptjs');
const prisma = require('../config/database');
const { auth, roleCheck } = require('../middleware/auth');

router.use(auth, roleCheck('ADMIN'));

// ─── Dashboard ───
router.get('/dashboard', async (req, res) => {
  try {
    const adminId = req.user.adminId;
    const { startDate, endDate } = req.query;

    const dateFilter = {};
    if (startDate) dateFilter.gte = new Date(startDate);
    if (endDate) dateFilter.lte = new Date(endDate + 'T23:59:59.999Z');

    const txWhere = {
      merchant: { adminId },
      ...(startDate || endDate ? { createdAt: dateFilter } : {})
    };

    const [
      totalRtgs, totalPending, totalCleared,
      adminCommission, merchantCount, agentCount, collectorCount
    ] = await Promise.all([
      prisma.transaction.aggregate({ where: { ...txWhere, status: 'CLEARED' }, _sum: { amount: true }, _count: true }),
      prisma.transaction.count({ where: { ...txWhere, status: 'PENDING' } }),
      prisma.transaction.count({ where: { ...txWhere, status: 'CLEARED' } }),
      prisma.transaction.aggregate({ where: { ...txWhere, status: 'CLEARED' }, _sum: { adminCommission: true } }),
      prisma.merchant.count({ where: { adminId } }),
      prisma.agent.count({ where: { adminId } }),
      prisma.collector.count({ where: { adminId } }),
    ]);

    res.json({
      success: true,
      data: {
        totalRtgsAmount: totalRtgs._sum.amount || 0,
        totalRtgsCount: totalRtgs._count || 0,
        totalPending,
        totalCleared,
        totalAdminCommission: adminCommission._sum.adminCommission || 0,
        merchantCount,
        agentCount,
        collectorCount,
      }
    });
  } catch (error) {
    console.error('Admin dashboard error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ═══════════════════════════════════════════
// MERCHANTS
// ═══════════════════════════════════════════
router.get('/merchants', async (req, res) => {
  try {
    const { page = 1, limit = 10, search } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const where = { adminId: req.user.adminId };

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { user: { username: { contains: search, mode: 'insensitive' } } }
      ];
    }

    const [merchants, total] = await Promise.all([
      prisma.merchant.findMany({
        where,
        include: {
          user: { select: { id: true, username: true, isActive: true } },
          _count: { select: { transactions: true } }
        },
        orderBy: { createdAt: 'desc' },
        skip, take: parseInt(limit),
      }),
      prisma.merchant.count({ where })
    ]);

    res.json({ success: true, data: merchants, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (error) {
    console.error('List merchants error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.post('/merchants', async (req, res) => {
  try {
    const { name, description, maxPaymentLimit, commissionChargePercent, assignAgentIds, username, password } = req.body;

    if (!name || !maxPaymentLimit || !commissionChargePercent || !username || !password) {
      return res.status(400).json({ success: false, message: 'Required fields: name, maxPaymentLimit, commissionChargePercent, username, password.' });
    }

    const exists = await prisma.user.findUnique({ where: { username: username.toLowerCase().trim() } });
    if (exists) return res.status(400).json({ success: false, message: 'Username already exists.' });

    const hashedPassword = await bcrypt.hash(password, 10);

    const result = await prisma.$transaction(async (tx) => {
      const merchant = await tx.merchant.create({
        data: {
          name,
          description,
          maxPaymentLimit: parseFloat(maxPaymentLimit),
          commissionChargePercent: parseFloat(commissionChargePercent),
          adminId: req.user.adminId,
        }
      });

      const user = await tx.user.create({
        data: {
          name,
          username: username.toLowerCase().trim(),
          password: hashedPassword,
          role: 'MERCHANT',
          merchantId: merchant.id,
          createdBy: req.user.id,
        }
      });

      // Assign agents if provided
      if (assignAgentIds?.length) {
        await tx.merchantAgent.createMany({
          data: assignAgentIds.map(agentId => ({ merchantId: merchant.id, agentId: parseInt(agentId) }))
        });
      }

      return { merchant, user };
    });

    res.status(201).json({ success: true, message: 'Merchant created.', data: result.merchant });
  } catch (error) {
    console.error('Create merchant error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.put('/merchants/:id', async (req, res) => {
  try {
    const merchantId = parseInt(req.params.id);
    const { name, description, maxPaymentLimit, commissionChargePercent, isActive, assignAgentIds } = req.body;

    const updateData = {};
    if (name) updateData.name = name;
    if (description !== undefined) updateData.description = description;
    if (maxPaymentLimit) updateData.maxPaymentLimit = parseFloat(maxPaymentLimit);
    if (commissionChargePercent) updateData.commissionChargePercent = parseFloat(commissionChargePercent);
    if (typeof isActive === 'boolean') updateData.isActive = isActive;

    await prisma.$transaction(async (tx) => {
      await tx.merchant.update({ where: { id: merchantId }, data: updateData });

      if (name) {
        const user = await tx.user.findFirst({ where: { merchantId } });
        if (user) await tx.user.update({ where: { id: user.id }, data: { name, isActive: isActive ?? user.isActive } });
      }

      if (assignAgentIds) {
        await tx.merchantAgent.deleteMany({ where: { merchantId } });
        if (assignAgentIds.length) {
          await tx.merchantAgent.createMany({
            data: assignAgentIds.map(agentId => ({ merchantId, agentId: parseInt(agentId) }))
          });
        }
      }
    });

    res.json({ success: true, message: 'Merchant updated.' });
  } catch (error) {
    console.error('Update merchant error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.delete('/merchants/:id', async (req, res) => {
  try {
    const merchantId = parseInt(req.params.id);
    await prisma.$transaction(async (tx) => {
      await tx.merchant.update({ where: { id: merchantId }, data: { isActive: false } });
      const user = await tx.user.findFirst({ where: { merchantId } });
      if (user) await tx.user.update({ where: { id: user.id }, data: { isActive: false } });
    });
    res.json({ success: true, message: 'Merchant deactivated.' });
  } catch (error) {
    console.error('Delete merchant error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ═══════════════════════════════════════════
// AGENTS
// ═══════════════════════════════════════════
router.get('/agents', async (req, res) => {
  try {
    const { page = 1, limit = 10, search } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const where = { adminId: req.user.adminId };
    if (search) where.name = { contains: search, mode: 'insensitive' };

    const [agents, total] = await Promise.all([
      prisma.agent.findMany({
        where,
        include: {
          user: { select: { id: true, username: true, isActive: true } },
          _count: { select: { operators: true } }
        },
        orderBy: { createdAt: 'desc' },
        skip, take: parseInt(limit),
      }),
      prisma.agent.count({ where })
    ]);

    res.json({ success: true, data: agents, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (error) {
    console.error('List agents error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.post('/agents', async (req, res) => {
  try {
    const { name, description, commissionChargePercent, username, password } = req.body;

    if (!name || !commissionChargePercent || !username || !password) {
      return res.status(400).json({ success: false, message: 'Required: name, commissionChargePercent, username, password.' });
    }

    const exists = await prisma.user.findUnique({ where: { username: username.toLowerCase().trim() } });
    if (exists) return res.status(400).json({ success: false, message: 'Username already exists.' });

    const hashedPassword = await bcrypt.hash(password, 10);

    const result = await prisma.$transaction(async (tx) => {
      const agent = await tx.agent.create({
        data: {
          name, description,
          commissionChargePercent: parseFloat(commissionChargePercent),
          adminId: req.user.adminId,
        }
      });

      const user = await tx.user.create({
        data: {
          name,
          username: username.toLowerCase().trim(),
          password: hashedPassword,
          role: 'AGENT',
          agentId: agent.id,
          createdBy: req.user.id,
        }
      });

      return { agent, user };
    });

    res.status(201).json({ success: true, message: 'Agent created.', data: result.agent });
  } catch (error) {
    console.error('Create agent error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.put('/agents/:id', async (req, res) => {
  try {
    const agentId = parseInt(req.params.id);
    const { name, description, commissionChargePercent, isActive } = req.body;

    const updateData = {};
    if (name) updateData.name = name;
    if (description !== undefined) updateData.description = description;
    if (commissionChargePercent) updateData.commissionChargePercent = parseFloat(commissionChargePercent);
    if (typeof isActive === 'boolean') updateData.isActive = isActive;

    await prisma.$transaction(async (tx) => {
      await tx.agent.update({ where: { id: agentId }, data: updateData });
      if (name) {
        const user = await tx.user.findFirst({ where: { agentId } });
        if (user) await tx.user.update({ where: { id: user.id }, data: { name, isActive: isActive ?? user.isActive } });
      }
    });

    res.json({ success: true, message: 'Agent updated.' });
  } catch (error) {
    console.error('Update agent error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.delete('/agents/:id', async (req, res) => {
  try {
    const agentId = parseInt(req.params.id);
    await prisma.$transaction(async (tx) => {
      await tx.agent.update({ where: { id: agentId }, data: { isActive: false } });
      const user = await tx.user.findFirst({ where: { agentId } });
      if (user) await tx.user.update({ where: { id: user.id }, data: { isActive: false } });
    });
    res.json({ success: true, message: 'Agent deactivated.' });
  } catch (error) {
    console.error('Delete agent error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ═══════════════════════════════════════════
// COLLECTORS
// ═══════════════════════════════════════════
router.get('/collectors', async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const where = { adminId: req.user.adminId };

    const [collectors, total] = await Promise.all([
      prisma.collector.findMany({
        where,
        include: { user: { select: { id: true, username: true, isActive: true } } },
        orderBy: { createdAt: 'desc' },
        skip, take: parseInt(limit),
      }),
      prisma.collector.count({ where })
    ]);

    res.json({ success: true, data: collectors, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.post('/collectors', async (req, res) => {
  try {
    const { name, description, username, password } = req.body;

    if (!name || !username || !password) {
      return res.status(400).json({ success: false, message: 'Required: name, username, password.' });
    }

    const exists = await prisma.user.findUnique({ where: { username: username.toLowerCase().trim() } });
    if (exists) return res.status(400).json({ success: false, message: 'Username already exists.' });

    const hashedPassword = await bcrypt.hash(password, 10);

    const result = await prisma.$transaction(async (tx) => {
      const collector = await tx.collector.create({
        data: { name, description, adminId: req.user.adminId }
      });

      await tx.user.create({
        data: {
          name,
          username: username.toLowerCase().trim(),
          password: hashedPassword,
          role: 'COLLECTOR',
          collectorId: collector.id,
          createdBy: req.user.id,
        }
      });

      return collector;
    });

    res.status(201).json({ success: true, message: 'Collector created.', data: result });
  } catch (error) {
    console.error('Create collector error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ═══════════════════════════════════════════
// ADMIN TRANSACTIONS (Read-only, full visibility)
// ═══════════════════════════════════════════
router.get('/transactions', async (req, res) => {
  try {
    const { page = 1, limit = 10, status, merchantId, agentId, operatorId, startDate, endDate, search } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const where = { merchant: { adminId: req.user.adminId } };
    if (status) where.status = status;
    if (merchantId) where.merchantId = parseInt(merchantId);
    if (agentId) where.agentId = parseInt(agentId);
    if (operatorId) where.operatorId = parseInt(operatorId);
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = new Date(startDate);
      if (endDate) where.createdAt.lte = new Date(endDate + 'T23:59:59.999Z');
    }
    if (search) {
      where.OR = [
        { utrNumber: { contains: search, mode: 'insensitive' } },
        { upiId: { contains: search, mode: 'insensitive' } },
        { accountHolderName: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [transactions, total] = await Promise.all([
      prisma.transaction.findMany({
        where,
        include: {
          merchant: { select: { id: true, name: true } },
          agent: { select: { id: true, name: true } },
          operator: { select: { id: true, name: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip, take: parseInt(limit),
      }),
      prisma.transaction.count({ where })
    ]);

    res.json({ success: true, data: transactions, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (error) {
    console.error('Admin transactions error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ═══════════════════════════════════════════
// COLLECTIONS (Admin → Merchant)
// ═══════════════════════════════════════════
router.post('/collections', async (req, res) => {
  try {
    const { amount, merchantId, description } = req.body;
    if (!amount || !merchantId) {
      return res.status(400).json({ success: false, message: 'Amount and merchantId required.' });
    }

    const collection = await prisma.collection.create({
      data: {
        amount: parseFloat(amount),
        merchantId: parseInt(merchantId),
        description,
      }
    });

    res.status(201).json({ success: true, message: 'Collection created.', data: collection });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.get('/collections', async (req, res) => {
  try {
    const { page = 1, limit = 10, status, merchantId, startDate, endDate } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const where = {};
    if (status) where.status = status;
    if (merchantId) where.merchantId = parseInt(merchantId);
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = new Date(startDate);
      if (endDate) where.createdAt.lte = new Date(endDate + 'T23:59:59.999Z');
    }

    const [collections, total] = await Promise.all([
      prisma.collection.findMany({
        where,
        include: { merchant: { select: { id: true, name: true } } },
        orderBy: { createdAt: 'desc' },
        skip, take: parseInt(limit),
      }),
      prisma.collection.count({ where })
    ]);

    res.json({ success: true, data: collections, total });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ═══════════════════════════════════════════
// BLOCKED IFSC
// ═══════════════════════════════════════════
router.get('/blocked-ifsc', async (req, res) => {
  try {
    const data = await prisma.blockedIfsc.findMany({ where: { adminId: req.user.adminId }, orderBy: { createdAt: 'desc' } });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.post('/blocked-ifsc', async (req, res) => {
  try {
    const { ifscCode, reason } = req.body;
    if (!ifscCode) return res.status(400).json({ success: false, message: 'IFSC code required.' });

    const blocked = await prisma.blockedIfsc.create({
      data: { ifscCode: ifscCode.toUpperCase(), reason, adminId: req.user.adminId }
    });
    res.status(201).json({ success: true, data: blocked });
  } catch (error) {
    if (error.code === 'P2002') return res.status(400).json({ success: false, message: 'IFSC already blocked.' });
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.delete('/blocked-ifsc/:id', async (req, res) => {
  try {
    await prisma.blockedIfsc.delete({ where: { id: parseInt(req.params.id) } });
    res.json({ success: true, message: 'IFSC unblocked.' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ═══════════════════════════════════════════
// BENEFICIARY ACCOUNTS
// ═══════════════════════════════════════════
router.get('/beneficiary-accounts', async (req, res) => {
  try {
    const data = await prisma.beneficiaryAccount.findMany({ orderBy: { createdAt: 'desc' } });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.post('/beneficiary-accounts', async (req, res) => {
  try {
    const { accountNumber, ifscCode, accountHolderName, bankName, upiId } = req.body;
    const account = await prisma.beneficiaryAccount.create({
      data: { accountNumber, ifscCode, accountHolderName, bankName, upiId }
    });
    res.status(201).json({ success: true, data: account });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ═══════════════════════════════════════════
// CASH ENTRIES
// ═══════════════════════════════════════════
router.get('/cash-entries', async (req, res) => {
  try {
    const data = await prisma.cashEntry.findMany({
      where: { adminId: req.user.adminId },
      orderBy: { createdAt: 'desc' }
    });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.post('/cash-entries', async (req, res) => {
  try {
    const { entryType, amount, description } = req.body;
    const entry = await prisma.cashEntry.create({
      data: { entryType, amount: parseFloat(amount), description, adminId: req.user.adminId }
    });
    res.status(201).json({ success: true, data: entry });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
