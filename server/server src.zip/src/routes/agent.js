// ============================================
// Agent Routes
// ============================================
const router = require('express').Router();
const bcrypt = require('bcryptjs');
const prisma = require('../config/database');
const { auth, roleCheck } = require('../middleware/auth');

router.use(auth, roleCheck('AGENT'));

// ─── Dashboard ───
router.get('/dashboard', async (req, res) => {
  try {
    const agentId = req.user.agentId;
    const { startDate, endDate } = req.query;

    const dateFilter = {};
    if (startDate) dateFilter.gte = new Date(startDate);
    if (endDate) dateFilter.lte = new Date(endDate + 'T23:59:59.999Z');

    const txWhere = { agentId, ...(startDate || endDate ? { createdAt: dateFilter } : {}) };

    const [commAgg, payOutAgg, payOutCount, payOutByOp, txByOp] = await Promise.all([
      prisma.transaction.aggregate({ where: { ...txWhere, status: 'CLEARED' }, _sum: { agentCommission: true } }),
      prisma.transaction.aggregate({ where: { ...txWhere, status: 'CLEARED' }, _sum: { amount: true } }),
      prisma.transaction.count({ where: { ...txWhere, status: 'CLEARED' } }),
      prisma.transaction.aggregate({ where: { ...txWhere, status: 'CLEARED' }, _sum: { amount: true } }),
      prisma.transaction.count({ where: { ...txWhere, status: 'CLEARED' } }),
    ]);

    res.json({
      success: true,
      data: {
        totalAgentCommission: commAgg._sum.agentCommission || 0,
        totalPayOutAmount: payOutAgg._sum.amount || 0,
        totalPayOutTransactions: payOutCount,
        payOutAmountByOperator: payOutByOp._sum.amount || 0,
        payOutTransactionsByOperator: txByOp,
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── Operators (Config entities) ───
router.get('/operators', async (req, res) => {
  try {
    const { search, startDate, endDate } = req.query;
    const where = { agentId: req.user.agentId };
    if (search) where.name = { contains: search, mode: 'insensitive' };

    const data = await prisma.operator.findMany({
      where,
      orderBy: { createdAt: 'desc' }
    });

    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.post('/operators', async (req, res) => {
  try {
    const { name, maxTransactionAmount, minTransactionAmount, commissionChargePercent, description } = req.body;

    if (!name || !maxTransactionAmount || !minTransactionAmount || !commissionChargePercent) {
      return res.status(400).json({ success: false, message: 'All fields required.' });
    }

    const operator = await prisma.operator.create({
      data: {
        name,
        maxTransactionAmount: parseFloat(maxTransactionAmount),
        minTransactionAmount: parseFloat(minTransactionAmount),
        commissionChargePercent: parseFloat(commissionChargePercent),
        description,
        agentId: req.user.agentId,
      }
    });

    res.status(201).json({ success: true, data: operator });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.put('/operators/:id', async (req, res) => {
  try {
    const { name, maxTransactionAmount, minTransactionAmount, commissionChargePercent, description, isActive } = req.body;
    const updateData = {};
    if (name) updateData.name = name;
    if (maxTransactionAmount) updateData.maxTransactionAmount = parseFloat(maxTransactionAmount);
    if (minTransactionAmount) updateData.minTransactionAmount = parseFloat(minTransactionAmount);
    if (commissionChargePercent) updateData.commissionChargePercent = parseFloat(commissionChargePercent);
    if (description !== undefined) updateData.description = description;
    if (typeof isActive === 'boolean') updateData.isActive = isActive;

    await prisma.operator.update({ where: { id: parseInt(req.params.id) }, data: updateData });
    res.json({ success: true, message: 'Operator updated.' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.delete('/operators/:id', async (req, res) => {
  try {
    await prisma.operator.update({ where: { id: parseInt(req.params.id) }, data: { isActive: false } });
    res.json({ success: true, message: 'Operator deactivated.' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── Operator Users (Login accounts) ───
router.get('/operator-users', async (req, res) => {
  try {
    const { operatorId, search } = req.query;
    const where = { role: 'OPERATOR', operator: { agentId: req.user.agentId } };
    if (operatorId) where.operatorId = parseInt(operatorId);
    if (search) where.name = { contains: search, mode: 'insensitive' };

    const data = await prisma.user.findMany({
      where,
      select: {
        id: true, name: true, username: true, isActive: true, createdAt: true,
        operator: { select: { id: true, name: true } }
      },
      orderBy: { createdAt: 'desc' }
    });

    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.post('/operator-users', async (req, res) => {
  try {
    const { username, password, operatorId } = req.body;
    if (!username || !password || !operatorId) {
      return res.status(400).json({ success: false, message: 'Username, password, operatorId required.' });
    }

    const exists = await prisma.user.findUnique({ where: { username: username.toLowerCase().trim() } });
    if (exists) return res.status(400).json({ success: false, message: 'Username exists.' });

    // Verify operator belongs to this agent
    const operator = await prisma.operator.findFirst({
      where: { id: parseInt(operatorId), agentId: req.user.agentId }
    });
    if (!operator) return res.status(400).json({ success: false, message: 'Invalid operator.' });

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await prisma.user.create({
      data: {
        name: username,
        username: username.toLowerCase().trim(),
        password: hashedPassword,
        role: 'OPERATOR',
        operatorId: parseInt(operatorId),
        createdBy: req.user.id,
      }
    });

    res.status(201).json({ success: true, data: { id: user.id, username: user.username } });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.put('/operator-users/:id', async (req, res) => {
  try {
    const { username, password, operatorId, isActive } = req.body;
    const updateData = {};
    if (username) updateData.username = username.toLowerCase().trim();
    if (password) updateData.password = await bcrypt.hash(password, 10);
    if (operatorId) updateData.operatorId = parseInt(operatorId);
    if (typeof isActive === 'boolean') updateData.isActive = isActive;

    await prisma.user.update({ where: { id: parseInt(req.params.id) }, data: updateData });
    res.json({ success: true, message: 'Operator user updated.' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.delete('/operator-users/:id', async (req, res) => {
  try {
    await prisma.user.update({ where: { id: parseInt(req.params.id) }, data: { isActive: false } });
    res.json({ success: true, message: 'Operator user deactivated.' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── Agent Transactions ───
router.get('/transactions', async (req, res) => {
  try {
    const { page = 1, limit = 10, status, operatorId, startDate, endDate, search } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const where = { agentId: req.user.agentId };
    if (status) where.status = status;
    if (operatorId) where.operatorId = parseInt(operatorId);
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = new Date(startDate);
      if (endDate) where.createdAt.lte = new Date(endDate + 'T23:59:59.999Z');
    }
    if (search) {
      where.OR = [
        { utrNumber: { contains: search, mode: 'insensitive' } },
        { upiId: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [transactions, total] = await Promise.all([
      prisma.transaction.findMany({
        where,
        include: {
          merchant: { select: { name: true, maxPaymentLimit: true } },
          operator: { select: { name: true, maxTransactionAmount: true, minTransactionAmount: true, transactionPicked: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip, take: parseInt(limit),
      }),
      prisma.transaction.count({ where })
    ]);

    res.json({ success: true, data: transactions, total });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
