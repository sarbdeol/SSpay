// ============================================
// Collector Routes
// ============================================
const router = require('express').Router();
const prisma = require('../config/database');
const { auth, roleCheck } = require('../middleware/auth');

router.use(auth, roleCheck('COLLECTOR'));

router.get('/dashboard', async (req, res) => {
  try {
    const collectorId = req.user.collectorId;

    const [merchantOwed, settlements, expenses] = await Promise.all([
      prisma.settlement.aggregate({ where: { collectorId, status: 'PENDING' }, _sum: { amount: true } }),
      prisma.settlement.aggregate({ where: { collectorId, status: 'APPROVED' }, _sum: { amount: true } }),
      prisma.expense.aggregate({ where: { collectorId }, _sum: { amount: true } }),
    ]);

    res.json({
      success: true,
      data: {
        totalMerchantSeLena: merchantOwed._sum.amount || 0,
        totalSettled: settlements._sum.amount || 0,
        totalExpenses: expenses._sum.amount || 0,
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── Expenses ───
router.get('/expenses', async (req, res) => {
  try {
    const data = await prisma.expense.findMany({
      where: { collectorId: req.user.collectorId },
      orderBy: { createdAt: 'desc' }
    });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.post('/expenses', async (req, res) => {
  try {
    const { category, amount, description } = req.body;
    if (!category || !amount) return res.status(400).json({ success: false, message: 'Category and amount required.' });

    const expense = await prisma.expense.create({
      data: {
        category,
        amount: parseFloat(amount),
        description,
        collectorId: req.user.collectorId,
      }
    });
    res.status(201).json({ success: true, data: expense });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── Requests ───
router.get('/requests', async (req, res) => {
  try {
    const data = await prisma.request.findMany({
      where: { collectorId: req.user.collectorId },
      orderBy: { createdAt: 'desc' }
    });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.post('/requests', async (req, res) => {
  try {
    const { amount, description } = req.body;
    if (!amount) return res.status(400).json({ success: false, message: 'Amount required.' });

    const request = await prisma.request.create({
      data: { amount: parseFloat(amount), description, collectorId: req.user.collectorId }
    });
    res.status(201).json({ success: true, data: request });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── Ledger ───
router.get('/ledger', async (req, res) => {
  try {
    const data = await prisma.ledger.findMany({
      where: { collectorId: req.user.collectorId },
      orderBy: { createdAt: 'desc' }
    });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
