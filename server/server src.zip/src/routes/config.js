// ============================================
// Config Routes - Rate Configuration
// ============================================
const router = require('express').Router();
const prisma = require('../config/database');
const { auth, roleCheck } = require('../middleware/auth');

router.use(auth, roleCheck('ADMIN'));

// ─── Get rates ───
router.get('/rates', async (req, res) => {
  try {
    const { merchantId, agentId } = req.query;
    const where = { adminId: req.user.adminId };
    if (merchantId) where.merchantId = parseInt(merchantId);
    if (agentId) where.agentId = parseInt(agentId);

    const data = await prisma.rateConfig.findMany({ where, orderBy: { updatedAt: 'desc' } });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── Set/Update rate ───
router.post('/rates', async (req, res) => {
  try {
    const { merchantId, agentId, usdtTodayRate, aedTodayRate, currency } = req.body;

    if (!usdtTodayRate || !aedTodayRate) {
      return res.status(400).json({ success: false, message: 'USDT and AED rates required.' });
    }

    // Check if rate exists for this merchant/agent
    const existingWhere = { adminId: req.user.adminId };
    if (merchantId) existingWhere.merchantId = parseInt(merchantId);
    if (agentId) existingWhere.agentId = parseInt(agentId);

    const existing = await prisma.rateConfig.findFirst({ where: existingWhere });

    let rate;
    if (existing) {
      rate = await prisma.rateConfig.update({
        where: { id: existing.id },
        data: {
          usdtTodayRate: parseFloat(usdtTodayRate),
          aedTodayRate: parseFloat(aedTodayRate),
          currency: currency || 'AED',
        }
      });
    } else {
      rate = await prisma.rateConfig.create({
        data: {
          usdtTodayRate: parseFloat(usdtTodayRate),
          aedTodayRate: parseFloat(aedTodayRate),
          currency: currency || 'AED',
          merchantId: merchantId ? parseInt(merchantId) : null,
          agentId: agentId ? parseInt(agentId) : null,
          adminId: req.user.adminId,
        }
      });
    }

    res.json({ success: true, message: 'Rate updated.', data: rate });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── Get current rates (for header dropdown - all roles) ───
router.get('/current-rates', async (req, res) => {
  try {
    const rates = await prisma.rateConfig.findMany({
      where: { isActive: true },
      orderBy: { updatedAt: 'desc' },
      take: 5,
      include: {
        merchant: { select: { name: true } },
        agent: { select: { name: true } }
      }
    });
    res.json({ success: true, data: rates });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
