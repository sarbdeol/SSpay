// ============================================
// Merchant Routes
// ============================================
const router = require('express').Router();
const bcrypt = require('bcryptjs');
const prisma = require('../config/database');
const { auth, roleCheck } = require('../middleware/auth');

router.use(auth, roleCheck('MERCHANT'));

// ─── Dashboard ───
router.get('/dashboard', async (req, res) => {
  try {
    const merchantId = req.user.merchantId;
    const { startDate, endDate } = req.query;

    const dateFilter = {};
    if (startDate) dateFilter.gte = new Date(startDate);
    if (endDate) dateFilter.lte = new Date(endDate + 'T23:59:59.999Z');

    const txWhere = {
      merchantId,
      ...(startDate || endDate ? { createdAt: dateFilter } : {})
    };

    const [merchant, commissionAgg, payOutAgg, payOutCount] = await Promise.all([
      prisma.merchant.findUnique({ where: { id: merchantId }, select: { maxPaymentLimit: true, usedLimit: true } }),
      prisma.transaction.aggregate({ where: { ...txWhere, status: 'CLEARED' }, _sum: { merchantCommission: true } }),
      prisma.transaction.aggregate({ where: { ...txWhere, status: 'CLEARED' }, _sum: { amount: true } }),
      prisma.transaction.count({ where: { ...txWhere, status: 'CLEARED' } }),
    ]);

    res.json({
      success: true,
      data: {
        totalCommissionAmount: commissionAgg._sum.merchantCommission || 0,
        totalPayOutAmount: payOutAgg._sum.amount || 0,
        totalPayOutTransactions: payOutCount,
        maxPaymentLimit: merchant?.maxPaymentLimit || 0,
        usedLimit: merchant?.usedLimit || 0,
        availableLimit: (merchant?.maxPaymentLimit || 0) - (merchant?.usedLimit || 0),
      }
    });
  } catch (error) {
    console.error('Merchant dashboard error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── Sub-Merchants ───
router.get('/submerchants', async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [subMerchants, total] = await Promise.all([
      prisma.subMerchant.findMany({
        where: { merchantId: req.user.merchantId },
        include: { user: { select: { id: true, username: true, isActive: true } } },
        orderBy: { createdAt: 'desc' },
        skip, take: parseInt(limit),
      }),
      prisma.subMerchant.count({ where: { merchantId: req.user.merchantId } })
    ]);

    res.json({ success: true, data: subMerchants, total });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.post('/submerchants', async (req, res) => {
  try {
    const { name, description, username, password } = req.body;
    if (!name || !username || !password) {
      return res.status(400).json({ success: false, message: 'Name, username, password required.' });
    }

    const exists = await prisma.user.findUnique({ where: { username: username.toLowerCase().trim() } });
    if (exists) return res.status(400).json({ success: false, message: 'Username already exists.' });

    const hashedPassword = await bcrypt.hash(password, 10);

    const result = await prisma.$transaction(async (tx) => {
      const subMerchant = await tx.subMerchant.create({
        data: { name, description, merchantId: req.user.merchantId }
      });

      await tx.user.create({
        data: {
          name,
          username: username.toLowerCase().trim(),
          password: hashedPassword,
          role: 'SUB_MERCHANT',
          subMerchantId: subMerchant.id,
          createdBy: req.user.id,
        }
      });

      return subMerchant;
    });

    res.status(201).json({ success: true, message: 'Sub-merchant created.', data: result });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── Transactions ───
router.get('/transactions', async (req, res) => {
  try {
    const { page = 1, limit = 10, status, startDate, endDate, search } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const where = { merchantId: req.user.merchantId };
    if (status) where.status = status;
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = new Date(startDate);
      if (endDate) where.createdAt.lte = new Date(endDate + 'T23:59:59.999Z');
    }
    if (search) {
      where.OR = [
        { utrNumber: { contains: search, mode: 'insensitive' } },
        { upiId: { contains: search, mode: 'insensitive' } },
        { accountHolderName: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [transactions, total] = await Promise.all([
      prisma.transaction.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip, take: parseInt(limit),
      }),
      prisma.transaction.count({ where })
    ]);

    res.json({ success: true, data: transactions, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.post('/transactions', async (req, res) => {
  try {
    const { transactionType, amount, upiId, accountNumber, ifscCode, accountHolderName, notes } = req.body;
    const merchantId = req.user.merchantId;

    if (!transactionType || !amount) {
      return res.status(400).json({ success: false, message: 'Transaction type and amount required.' });
    }

    // Check merchant limit
    const merchant = await prisma.merchant.findUnique({ where: { id: merchantId } });
    const available = parseFloat(merchant.maxPaymentLimit) - parseFloat(merchant.usedLimit);
    if (parseFloat(amount) > available) {
      return res.status(400).json({ success: false, message: `Insufficient limit. Available: ${available}` });
    }

    // Check blocked IFSC
    if (transactionType === 'BANK_ACCOUNT' && ifscCode) {
      const blocked = await prisma.blockedIfsc.findUnique({ where: { ifscCode: ifscCode.toUpperCase() } });
      if (blocked) return res.status(400).json({ success: false, message: 'This IFSC code is blocked.' });
    }

    // Validate fields based on type
    if (transactionType === 'UPI' && !upiId) {
      return res.status(400).json({ success: false, message: 'UPI ID required.' });
    }
    if (transactionType === 'BANK_ACCOUNT' && (!accountNumber || !ifscCode || !accountHolderName)) {
      return res.status(400).json({ success: false, message: 'Account number, IFSC, and holder name required.' });
    }

    const transaction = await prisma.$transaction(async (tx) => {
      const txn = await tx.transaction.create({
        data: {
          amount: parseFloat(amount),
          transactionType,
          merchantId,
          upiId: transactionType === 'UPI' ? upiId : null,
          accountNumber: transactionType === 'BANK_ACCOUNT' ? accountNumber : null,
          ifscCode: transactionType === 'BANK_ACCOUNT' ? ifscCode?.toUpperCase() : null,
          accountHolderName: transactionType === 'BANK_ACCOUNT' ? accountHolderName : null,
          notes,
        }
      });

      // Update merchant used limit
      await tx.merchant.update({
        where: { id: merchantId },
        data: { usedLimit: { increment: parseFloat(amount) } }
      });

      return txn;
    });

    res.status(201).json({ success: true, message: 'Transaction created.', data: transaction });
  } catch (error) {
    console.error('Create transaction error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.get('/transactions/:id', async (req, res) => {
  try {
    const transaction = await prisma.transaction.findFirst({
      where: { id: parseInt(req.params.id), merchantId: req.user.merchantId },
      include: {
        merchant: { select: { name: true, maxPaymentLimit: true } },
      }
    });
    if (!transaction) return res.status(404).json({ success: false, message: 'Not found.' });
    res.json({ success: true, data: transaction });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── Settlements to Collector ───
router.post('/settlements', async (req, res) => {
  try {
    const { amount, collectorId, remark } = req.body;
    if (!amount || !collectorId) {
      return res.status(400).json({ success: false, message: 'Amount and collector required.' });
    }

    const settlement = await prisma.settlement.create({
      data: {
        amount: parseFloat(amount),
        merchantId: req.user.merchantId,
        collectorId: parseInt(collectorId),
        remark,
      }
    });

    res.status(201).json({ success: true, data: settlement });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

router.get('/settlements', async (req, res) => {
  try {
    const { page = 1, limit = 10, status } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const where = { merchantId: req.user.merchantId };
    if (status) where.status = status;

    const [settlements, total] = await Promise.all([
      prisma.settlement.findMany({
        where,
        include: { collector: { select: { name: true } } },
        orderBy: { createdAt: 'desc' },
        skip, take: parseInt(limit),
      }),
      prisma.settlement.count({ where })
    ]);

    res.json({ success: true, data: settlements, total });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
