// ============================================
// Operator Routes (Operator User login)
// ============================================
const router = require("express").Router();
const prisma = require("../config/database");
const { auth, roleCheck } = require("../middleware/auth");

const multer = require("multer");

    const storage = multer.diskStorage({
      destination: "uploads/payment-proof",
      filename: (req, file, cb) => {
        cb(null, Date.now() + "-" + file.originalname);
      },
    });
  const upload = multer({ storage });

router.use(auth, roleCheck("OPERATOR"));
// ─── Dashboard ───
router.get("/dashboard", async (req, res) => {
  try {
    const operatorId = req.user.operatorId;
    const { startDate, endDate } = req.query;

    const dateFilter = {};
    if (startDate) dateFilter.gte = new Date(startDate);
    if (endDate) dateFilter.lte = new Date(endDate + "T23:59:59.999Z");

    const txWhere = {
      operatorId,
      ...(startDate || endDate ? { createdAt: dateFilter } : {}),
    };

    const [operator, transferAgg, pendingAgg, paymentLunga] = await Promise.all(
      [
        prisma.operator.findUnique({ where: { id: operatorId } }),
        prisma.transaction.aggregate({
          where: { ...txWhere, status: "CLEARED" },
          _sum: { amount: true },
          _count: true,
        }),
        prisma.transaction.aggregate({
          where: { ...txWhere, status: { in: ["PENDING", "PICKED"] } },
          _sum: { amount: true },
          _count: true,
        }),
        prisma.transaction.aggregate({
          where: { ...txWhere, status: "CLEARED" },
          _sum: { amount: true },
        }),
      ],
    );

    res.json({
      success: true,
      data: {
        totalTransferAmount: transferAgg._sum.amount || 0,
        totalTransferCount: transferAgg._count || 0,
        totalPendingAmount: pendingAgg._sum.amount || 0,
        totalPendingCount: pendingAgg._count || 0,
        totalPaymentLunga: paymentLunga._sum.amount || 0,
        availableDetails: {
          maxTransaction: operator?.maxTransactionAmount || 0,
          minTransaction: operator?.minTransactionAmount || 0,
          transactionPicked: operator?.transactionPicked || 0,
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error." });
  }
});

// ─── Transactions List ───
router.get("/transactions", async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      status,
      startDate,
      endDate,
      search,
    } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    

    const where = { operatorId: req.user.operatorId };
    if (status) where.status = status;
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = new Date(startDate);
      if (endDate) where.createdAt.lte = new Date(endDate + "T23:59:59.999Z");
    }
    if (search) {
      where.OR = [
        { utrNumber: { contains: search, mode: "insensitive" } },
        { upiId: { contains: search, mode: "insensitive" } },
      ];
    }

    const [transactions, total] = await Promise.all([
      prisma.transaction.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip,
        take: parseInt(limit),
      }),
      prisma.transaction.count({ where }),
    ]);

    res.json({ success: true, data: transactions, total });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error." });
  }
});

// ─── Pick a pending transaction ───
router.post("/transactions/:id/pick", async (req, res) => {
  try {
    const txId = parseInt(req.params.id);
    const operatorId = req.user.operatorId;

    const operator = await prisma.operator.findUnique({
      where: { id: operatorId },
    });

    // Check if transaction is still pending
    const tx = await prisma.transaction.findFirst({
      where: { id: txId, status: "PENDING" },
    });
    if (!tx)
      return res
        .status(404)
        .json({ success: false, message: "Transaction not found." });
    if (tx.status !== "PENDING")
      return res.status(400).json({
        success: false,
        message: "Transaction already picked or processed.",
      });

    // Check operator limits
    if (parseFloat(tx.amount) > parseFloat(operator.maxTransactionAmount)) {
      return res.status(400).json({
        success: false,
        message: "Amount exceeds operator max limit.",
      });
    }
    if (parseFloat(tx.amount) < parseFloat(operator.minTransactionAmount)) {
      return res
        .status(400)
        .json({ success: false, message: "Amount below operator min limit." });
    }

    // Get agent from operator
    const agentId = operator.agentId;

    await prisma.$transaction(async (prismaClient) => {
      await prismaClient.transaction.update({
        where: { id: txId },
        data: {
          status: "PICKED",
          operatorId,
          agentId,
          operatorPickTime: new Date(),
        },
      });

      await prismaClient.operator.update({
        where: { id: operatorId },
        data: { transactionPicked: { increment: 1 } },
      });
    });

    res.json({ success: true, message: "Transaction picked." });
  } catch (error) {
    console.error("Pick transaction error:", error);
    res.status(500).json({ success: false, message: "Server error." });
  }
});
// ─── Mark transaction as PAID ───
router.post("/transactions/:id/pay", async (req, res) => {
  try {
    const txId = parseInt(req.params.id);

    const tx = await prisma.transaction.findFirst({
      where: {
        id: txId,
        operatorId: req.user.operatorId,
        status: "PICKED",
      },
    });

    if (!tx)
      return res.status(400).json({
        success: false,
        message: "Transaction not found or not picked.",
      });

    await prisma.transaction.update({
      where: { id: txId },
      data: {
        status: "PAID",
      },
    });

    res.json({
      success: true,
      message: "Transaction marked as PAID.",
    });
  } catch (error) {
    console.error("Pay transaction error:", error);
    res.status(500).json({
      success: false,
      message: "Server error.",
    });
  }
});
// ─── Submit UTR (Clear transaction) ───
router.post(
  "/transactions/:id/clear",
  upload.single("proof"),
  async (req, res) => {
    try {
      const txId = parseInt(req.params.id);
      const { utrNumber } = req.body;

      if (!utrNumber)
        return res
          .status(400)
          .json({ success: false, message: "UTR number required." });

      const tx = await prisma.transaction.findFirst({
        where: { id: txId, operatorId: req.user.operatorId, status: "PAID" },
        include: {
          merchant: { select: { commissionChargePercent: true } },
          operator: {
            select: { commissionChargePercent: true, agentId: true },
          },
        },
      });

      if (!tx)
        return res.status(400).json({
          success: false,
          message: "Transaction not found or not in PICKED status.",
        });

      // Get agent commission
      const agent = await prisma.agent.findUnique({
        where: { id: tx.operator.agentId },
      });

      // Calculate commissions
      const amount = parseFloat(tx.amount);
      const merchantComm =
        (amount * parseFloat(tx.merchant.commissionChargePercent)) / 100;
      const agentComm =
        (amount * parseFloat(agent?.commissionChargePercent || 0)) / 100;
      const operatorComm =
        (amount * parseFloat(tx.operator.commissionChargePercent)) / 100;
      const adminComm = merchantComm - agentComm; // Admin gets the difference

      await prisma.$transaction(async (prismaClient) => {
        await prismaClient.transaction.update({
          where: { id: txId },
          data: {
            status: "CLEARED",
            utrNumber,
            proofImage: req.file ? req.file.filename : null,
            transactionClearTime: new Date(),
            merchantCommission: merchantComm,
            agentCommission: agentComm,
            operatorCommission: operatorComm,
            adminCommission: adminComm > 0 ? adminComm : 0,
          },
        });

        await prismaClient.operator.update({
          where: { id: req.user.operatorId },
          data: { transactionPicked: { decrement: 1 } },
        });
      });

      res.json({ success: true, message: "Transaction cleared." });
    } catch (error) {
      console.error("Clear transaction error:", error);
      res.status(500).json({ success: false, message: "Server error." });
    }
  },
);

// ─── Reject transaction ───
router.post("/transactions/:id/reject", async (req, res) => {
  try {
    const txId = parseInt(req.params.id);
    const { notes } = req.body;

    const tx = await prisma.transaction.findFirst({
      where: { id: txId, operatorId: req.user.operatorId, status: "PICKED" },
    });

    if (!tx)
      return res.status(400).json({
        success: false,
        message: "Transaction not found or not picked.",
      });

    await prisma.$transaction(async (prismaClient) => {
      await prismaClient.transaction.update({
        where: { id: txId },
        data: {
          status: "REJECTED",
          notes: notes || tx.notes,
          transactionClearTime: new Date(),
        },
      });

      // Restore merchant limit
      await prismaClient.merchant.update({
        where: { id: tx.merchantId },
        data: { usedLimit: { decrement: parseFloat(tx.amount) } },
      });

      await prismaClient.operator.update({
        where: { id: req.user.operatorId },
        data: { transactionPicked: { decrement: 1 } },
      });
    });

    res.json({ success: true, message: "Transaction rejected." });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error." });
  }
});

// ─── Get pending transactions to pick ───
router.get("/pending-transactions", async (req, res) => {
  try {
    const operator = await prisma.operator.findUnique({
      where: { id: req.user.operatorId },
    });

    // Get merchants assigned to this operator's agent
    const merchantAgents = await prisma.merchantAgent.findMany({
      where: { agentId: operator.agentId },
      select: { merchantId: true },
    });
    const merchantIds = merchantAgents.map((ma) => ma.merchantId);

    const transactions = await prisma.transaction.findMany({
      where: {
        status: "PENDING",
        merchantId: { in: merchantIds },
        amount: {
          gte: operator.minTransactionAmount,
          lte: operator.maxTransactionAmount,
        },
      },
      orderBy: { createdAt: "asc" },
      take: 20,
    });

    res.json({ success: true, data: transactions });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error." });
  }
});

module.exports = router;
