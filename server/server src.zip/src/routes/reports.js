// ============================================
// Reports Routes - Daily Report + Exports
// ============================================
const router = require('express').Router();
const prisma = require('../config/database');
const { auth } = require('../middleware/auth');
const ExcelJS = require('exceljs');
const PDFDocument = require('pdfkit');

router.use(auth);

// ─── Daily Report (All roles) ───
router.get('/daily', async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const user = req.user;

    if (!startDate || !endDate) {
      return res.status(400).json({ success: false, message: 'Start and end date required.' });
    }

    const dateFilter = {
      createdAt: {
        gte: new Date(startDate),
        lte: new Date(endDate + 'T23:59:59.999Z')
      }
    };

    let txWhere = { ...dateFilter, status: 'CLEARED' };

    // Scope by role
    if (user.role === 'MERCHANT') txWhere.merchantId = user.merchantId;
    else if (user.role === 'SUB_MERCHANT') txWhere.subMerchantId = user.subMerchantId;
    else if (user.role === 'AGENT') txWhere.agentId = user.agentId;
    else if (user.role === 'OPERATOR') txWhere.operatorId = user.operatorId;
    else if (user.role === 'ADMIN') txWhere.merchant = { adminId: user.adminId };

    const [payOut, commission] = await Promise.all([
      prisma.transaction.aggregate({ where: txWhere, _sum: { amount: true } }),
      prisma.transaction.aggregate({
        where: txWhere,
        _sum: {
          merchantCommission: true,
          agentCommission: true,
          operatorCommission: true,
          adminCommission: true,
        }
      }),
    ]);

    // Get commission based on role
    let totalCommission = 0;
    if (user.role === 'MERCHANT') totalCommission = commission._sum.merchantCommission || 0;
    else if (user.role === 'AGENT') totalCommission = commission._sum.agentCommission || 0;
    else if (user.role === 'OPERATOR') totalCommission = commission._sum.operatorCommission || 0;
    else if (user.role === 'ADMIN') totalCommission = commission._sum.adminCommission || 0;

    res.json({
      success: true,
      data: {
        totalPayOut: payOut._sum.amount || 0,
        totalCommission,
        amountByCurrency: null, // TODO: implement currency grouping
        startDate,
        endDate,
      }
    });
  } catch (error) {
    console.error('Daily report error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── PDF Report Download ───
router.get('/daily/pdf', async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const user = req.user;

    let txWhere = {
      status: 'CLEARED',
      createdAt: {
        gte: new Date(startDate),
        lte: new Date(endDate + 'T23:59:59.999Z')
      }
    };

    if (user.role === 'MERCHANT') txWhere.merchantId = user.merchantId;
    else if (user.role === 'AGENT') txWhere.agentId = user.agentId;
    else if (user.role === 'OPERATOR') txWhere.operatorId = user.operatorId;

    const transactions = await prisma.transaction.findMany({
      where: txWhere,
      orderBy: { createdAt: 'desc' },
      include: { merchant: { select: { name: true } } }
    });

    const payOut = transactions.reduce((s, t) => s + parseFloat(t.amount), 0);

    // Create PDF
    const doc = new PDFDocument({ margin: 50 });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename=daily-report-${startDate}-${endDate}.pdf`);
    doc.pipe(res);

    // Header
    doc.fontSize(20).font('Helvetica-Bold').text('INDU PAY', { align: 'center' });
    doc.fontSize(12).font('Helvetica').text('Daily Report', { align: 'center' });
    doc.moveDown();
    doc.fontSize(10).text(`Period: ${startDate} to ${endDate}`);
    doc.text(`Generated: ${new Date().toISOString().split('T')[0]}`);
    doc.text(`Role: ${user.role}`);
    doc.moveDown();

    // Summary
    doc.fontSize(14).font('Helvetica-Bold').text('Summary');
    doc.fontSize(11).font('Helvetica');
    doc.text(`Total Pay Out: ₹${payOut.toLocaleString()}`);
    doc.text(`Total Transactions: ${transactions.length}`);
    doc.moveDown();

    // Table header
    if (transactions.length > 0) {
      doc.fontSize(12).font('Helvetica-Bold').text('Transactions');
      doc.moveDown(0.5);

      const tableTop = doc.y;
      doc.fontSize(8).font('Helvetica-Bold');
      doc.text('ID', 50, tableTop);
      doc.text('Amount', 100, tableTop);
      doc.text('Type', 180, tableTop);
      doc.text('Status', 260, tableTop);
      doc.text('UTR', 330, tableTop);
      doc.text('Date', 430, tableTop);

      doc.moveTo(50, tableTop + 15).lineTo(550, tableTop + 15).stroke();

      let y = tableTop + 20;
      doc.font('Helvetica').fontSize(8);

      transactions.forEach(tx => {
        if (y > 720) {
          doc.addPage();
          y = 50;
        }
        doc.text(tx.id.toString(), 50, y);
        doc.text(`₹${parseFloat(tx.amount).toLocaleString()}`, 100, y);
        doc.text(tx.transactionType, 180, y);
        doc.text(tx.status, 260, y);
        doc.text(tx.utrNumber || '-', 330, y);
        doc.text(tx.createdAt.toISOString().split('T')[0], 430, y);
        y += 15;
      });
    }

    doc.end();
  } catch (error) {
    console.error('PDF report error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// ─── Excel Export ───
router.get('/export/transactions', async (req, res) => {
  try {
    const { startDate, endDate, status, merchantId, agentId, operatorId } = req.query;
    const user = req.user;

    const where = {};
    if (status) where.status = status;
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = new Date(startDate);
      if (endDate) where.createdAt.lte = new Date(endDate + 'T23:59:59.999Z');
    }

    // Scope by role
    if (user.role === 'MERCHANT') where.merchantId = user.merchantId;
    else if (user.role === 'SUB_MERCHANT') where.subMerchantId = user.subMerchantId;
    else if (user.role === 'AGENT') where.agentId = user.agentId;
    else if (user.role === 'OPERATOR') where.operatorId = user.operatorId;
    else if (user.role === 'ADMIN') {
      where.merchant = { adminId: user.adminId };
      if (merchantId) where.merchantId = parseInt(merchantId);
      if (agentId) where.agentId = parseInt(agentId);
      if (operatorId) where.operatorId = parseInt(operatorId);
    }

    const transactions = await prisma.transaction.findMany({
      where,
      include: {
        merchant: { select: { name: true } },
        agent: { select: { name: true } },
        operator: { select: { name: true } },
      },
      orderBy: { createdAt: 'desc' }
    });

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('Transactions');

    sheet.columns = [
      { header: 'ID', key: 'id', width: 8 },
      { header: 'Amount', key: 'amount', width: 12 },
      { header: 'Type', key: 'transactionType', width: 14 },
      { header: 'UTR Number', key: 'utrNumber', width: 18 },
      { header: 'Bank Name', key: 'bankName', width: 15 },
      { header: 'IFSC', key: 'ifscCode', width: 12 },
      { header: 'Account Number', key: 'accountNumber', width: 18 },
      { header: 'Account Holder', key: 'accountHolderName', width: 18 },
      { header: 'UPI ID', key: 'upiId', width: 22 },
      { header: 'Merchant', key: 'merchantName', width: 15 },
      { header: 'Agent', key: 'agentName', width: 15 },
      { header: 'Operator', key: 'operatorName', width: 15 },
      { header: 'Notes', key: 'notes', width: 15 },
      { header: 'Status', key: 'status', width: 10 },
      { header: 'Created Date', key: 'createdAt', width: 20 },
      { header: 'Cleared Date', key: 'transactionClearTime', width: 20 },
    ];

    // Style header
    sheet.getRow(1).font = { bold: true };
    sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE5E5EA' } };

    transactions.forEach(tx => {
      sheet.addRow({
        id: tx.id,
        amount: parseFloat(tx.amount),
        transactionType: tx.transactionType,
        utrNumber: tx.utrNumber || '',
        bankName: tx.bankName || '',
        ifscCode: tx.ifscCode || '',
        accountNumber: tx.accountNumber || '',
        accountHolderName: tx.accountHolderName || '',
        upiId: tx.upiId || '',
        merchantName: tx.merchant?.name || '',
        agentName: tx.agent?.name || '',
        operatorName: tx.operator?.name || '',
        notes: tx.notes || '',
        status: tx.status,
        createdAt: tx.createdAt?.toISOString() || '',
        transactionClearTime: tx.transactionClearTime?.toISOString() || '',
      });
    });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=transactions-${Date.now()}.xlsx`);
    await workbook.xlsx.write(res);
  } catch (error) {
    console.error('Export error:', error);
    res.status(500).json({ success: false, message: 'Export failed.' });
  }
});

// ─── Transaction Receipt PDF ───
router.get('/receipt/:transactionId', async (req, res) => {
  try {
    const tx = await prisma.transaction.findUnique({
      where: { id: parseInt(req.params.transactionId) },
      include: { merchant: { select: { name: true } } }
    });

    if (!tx || tx.status !== 'CLEARED') {
      return res.status(404).json({ success: false, message: 'Cleared transaction not found.' });
    }

    const doc = new PDFDocument({ margin: 50, size: 'A5' });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename=receipt-${tx.id}.pdf`);
    doc.pipe(res);

    doc.fontSize(18).font('Helvetica-Bold').text('INDU PAY', { align: 'center' });
    doc.fontSize(10).font('Helvetica').text('Transaction Receipt', { align: 'center' });
    doc.moveDown(2);

    const details = [
      ['Transaction ID', `#${tx.id}`],
      ['Amount', `₹${parseFloat(tx.amount).toLocaleString()}`],
      ['Type', tx.transactionType],
      ['UPI ID', tx.upiId || '-'],
      ['Bank Account', tx.accountNumber || '-'],
      ['IFSC', tx.ifscCode || '-'],
      ['Holder Name', tx.accountHolderName || '-'],
      ['UTR Number', tx.utrNumber || '-'],
      ['Status', tx.status],
      ['Created', tx.createdAt.toISOString().replace('T', ' ').substring(0, 19)],
      ['Cleared', tx.transactionClearTime?.toISOString().replace('T', ' ').substring(0, 19) || '-'],
    ];

    details.forEach(([label, value]) => {
      doc.fontSize(9).font('Helvetica-Bold').text(label + ': ', { continued: true });
      doc.font('Helvetica').text(value);
    });

    doc.moveDown(2);
    doc.fontSize(8).fillColor('gray').text('This is a system-generated receipt.', { align: 'center' });

    doc.end();
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
