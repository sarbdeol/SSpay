// ============================================
// Super Admin Routes
// ============================================
const router = require('express').Router();
const bcrypt = require('bcryptjs');
const prisma = require('../config/database');
const { auth, roleCheck } = require('../middleware/auth');

// All routes require SUPER_ADMIN role
router.use(auth, roleCheck('SUPER_ADMIN'));

/**
 * GET /api/superadmin/dashboard
 * Dashboard stats
 */
router.get('/dashboard', async (req, res) => {
  try {
    const [totalAdmins, totalMerchants, totalAgents, totalCollectors, totalUsers] = await Promise.all([
      prisma.admin.count(),
      prisma.merchant.count(),
      prisma.agent.count(),
      prisma.collector.count(),
      prisma.user.count(),
    ]);

    res.json({
      success: true,
      data: { totalAdmins, totalMerchants, totalAgents, totalCollectors, totalUsers }
    });
  } catch (error) {
    console.error('SuperAdmin dashboard error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * GET /api/superadmin/admins
 * List all admins
 */
router.get('/admins', async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [admins, total] = await Promise.all([
      prisma.user.findMany({
        where: { role: 'ADMIN' },
        select: {
          id: true, name: true, username: true, isActive: true, createdAt: true,
          admin: { select: { id: true, name: true } }
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: parseInt(limit),
      }),
      prisma.user.count({ where: { role: 'ADMIN' } })
    ]);

    res.json({ success: true, data: admins, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (error) {
    console.error('List admins error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * POST /api/superadmin/admins
 * Create new admin
 */
router.post('/admins', async (req, res) => {
  try {
    const { name, username, password } = req.body;

    if (!name || !username || !password) {
      return res.status(400).json({ success: false, message: 'Name, username, and password are required.' });
    }

    // Check username exists
    const exists = await prisma.user.findUnique({ where: { username: username.toLowerCase().trim() } });
    if (exists) {
      return res.status(400).json({ success: false, message: 'Username already exists.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    // Create admin profile + user in transaction
    const result = await prisma.$transaction(async (tx) => {
      const admin = await tx.admin.create({
        data: { name }
      });

      const user = await tx.user.create({
        data: {
          name,
          username: username.toLowerCase().trim(),
          password: hashedPassword,
          role: 'ADMIN',
          adminId: admin.id,
          createdBy: req.user.id,
        }
      });

      return { admin, user };
    });

    res.status(201).json({
      success: true,
      message: 'Admin created successfully.',
      data: { id: result.user.id, name: result.user.name, username: result.user.username }
    });
  } catch (error) {
    console.error('Create admin error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * PUT /api/superadmin/admins/:id
 * Update admin
 */
router.put('/admins/:id', async (req, res) => {
  try {
    const { name, isActive, password } = req.body;
    const userId = parseInt(req.params.id);

    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user || user.role !== 'ADMIN') {
      return res.status(404).json({ success: false, message: 'Admin not found.' });
    }

    const updateData = {};
    if (name) updateData.name = name;
    if (typeof isActive === 'boolean') updateData.isActive = isActive;
    if (password) updateData.password = await bcrypt.hash(password, 10);

    await prisma.$transaction(async (tx) => {
      await tx.user.update({ where: { id: userId }, data: updateData });
      if (name && user.adminId) {
        await tx.admin.update({ where: { id: user.adminId }, data: { name, isActive: updateData.isActive ?? true } });
      }
    });

    res.json({ success: true, message: 'Admin updated successfully.' });
  } catch (error) {
    console.error('Update admin error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * DELETE /api/superadmin/admins/:id
 * Delete admin (soft delete - deactivate)
 */
router.delete('/admins/:id', async (req, res) => {
  try {
    const userId = parseInt(req.params.id);
    await prisma.user.update({ where: { id: userId }, data: { isActive: false } });
    res.json({ success: true, message: 'Admin deactivated.' });
  } catch (error) {
    console.error('Delete admin error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * GET /api/superadmin/users
 * List all users across all roles
 */
router.get('/users', async (req, res) => {
  try {
    const { page = 1, limit = 10, role, search } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const where = {};
    if (role) where.role = role;
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { username: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        select: {
          id: true, name: true, username: true, role: true, isActive: true, createdAt: true,
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: parseInt(limit),
      }),
      prisma.user.count({ where })
    ]);

    res.json({ success: true, data: users, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (error) {
    console.error('List users error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
